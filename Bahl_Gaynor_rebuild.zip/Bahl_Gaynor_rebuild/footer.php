<?php

?>

		</div><!-- .site-content -->

		<footer>
			<div class="col-xs-12 footer-text">
				<p>&copy; Copyright <?php echo date("Y"); ?> | Bahl &amp; Gaynor Investment Counsel 255 East Fifth Street, Suite 2700 Cincinnati, OH 45202</p>
				<!-- LETS! GO! YANKEES! -->
				<p>P: 513.287.6100 / 800.341.1810 F: 513.287.6110 | E: info@bahl-gaynor.com | Disclaimer </p>
			</div><!-- .site-info -->
		</footer><!-- .site-footer -->
		
	</div><!-- .site-inner -->
</div><!-- .site -->


</script>

<?php wp_footer(); ?>
</body>
</html>
