<?if( have_rows('content') ):

	while ( have_rows('content') ) : the_row();

			$content_type=get_sub_field('content_type');
			$text_header=get_sub_field('text_header');
			$text_sub_header=get_sub_field('text_sub_header');
			$copy=get_sub_field('copy');
			$content_br=get_sub_field('content_br');

			switch ($content_type){
				case 'half_page_top':
/*					?><div class="content-left col-xs-12"><?
					?><h1><?echo $text_header;?></h1><?
					?><h3><?echo $text_sub_header;?></h3><?
					echo $copy;?>
					</div><?*/

				if( have_rows('half_page_top') ):

				while ( have_rows('half_page_top') ) : the_row();
						$header=get_sub_field('half_pg_header');
						$sub_header=get_sub_field('half_pg_sub_head');
						$body_copy=get_sub_field('half_pg_copy');
						
						?><div class="content-left col-xs-12"><?
						?>	<h1><?echo $header;?></h1><?
						?>	<h3><?echo $sub_header;?></h3><?
							echo $body_copy;?>
						</div>
				<?
				endwhile;

				else :
					echo "<h1> no content ya honkey </h1>";
				endif;

				break;
				case 'full_pg_divider':
					?><div class="content-divider"style="background-image:url('<?echo $content_br?>')"><?
				if( have_rows('divider_content') ):

				while ( have_rows('divider_content') ) : the_row();
						$big_text=get_sub_field('big_text');
						$small_text=get_sub_field('small_text');
						$sub_text=get_sub_field('sub_text');
									
						?>
						<div class="col-sm-12 col-md-4 divider-item">
							<div class="item-container">
							<h1><?echo $big_text;?>
							<span class="smallTxt"><?echo $small_text;?></span></h1>
							<p><?echo $sub_text;?></p>
							</div>
						</div>
				<?
				endwhile;

				else :
					echo "<h1> no content </h1>";
				endif;
						?></div><?
				break;		
				case 'full_pg':
					?><div class="content-full"><?
				if( have_rows('full_page_content') ):

				while ( have_rows('full_page_content') ) : the_row();
						$header=get_sub_field('full_pg_header');
						$sub_header=get_sub_field('full_pg_sub_head');
						$body_copy=get_sub_field('full_pg_copy');
						$content_type = get_sub_field('content_type');
						?>

						<?php switch ($content_type){
							case 'copy' : ?>
								<div class="col-xs-12">
									<div class="flex-center">
										<h1><?echo $header;?></h1>
										<?php if ($sub_header=='') : ?>
														<h3 style="display:none;"><?echo $sub_header;?></h3>
													<? else : ?>
														<h3><?echo $sub_header;?></h3>
														<?endif;?>
								
										<p><?echo $body_copy;?></p>
									</div>
								</div><?
							break;

						case 'post' : ?>

						
								<div class="max-width-container news">
									<div class="div-content dcn">
									<div class="news-inner">
										<?php if( have_rows('news_update') ):

											while ( have_rows('news_update') ) : the_row();
													$headline=get_sub_field('update_headline');
													$post_date=get_sub_field('post_date');
													$body_copy=get_sub_field('news_copy');
													?>

													<div class="post">
														<h2><?php echo $headline; ?></h2>
														<small> <?php echo $post_date;?> </small>
														<div>
														<?php echo $body_copy;?>
														</div>
													</div>

											<?
											endwhile;

											else :
												?><div class="post"><?
												echo "<h2> No news at this time. </h2>";
												?></div> <?
											endif;
														
					break;

					default:
				 		echo "No content";
				 	}
					?>

						
				<?
				endwhile;

				else :
					echo "<h1> no content </h1>";
				endif;
					?></div><?
				break;		
				case 'half_pg':
				?><?
				if( have_rows('half_page_content') ):
				?><div><?
				while ( have_rows('half_page_content') ) : the_row();
						$header=get_sub_field('half_pg_header');
						$sub_header=get_sub_field('half_pg_sub_head');
						$body_copy=get_sub_field('half_pg_copy');
						$half_pg_br=get_sub_field('half_page_br');
						$header_color=get_sub_field('header_color');
						$copy_color=get_sub_field('copy_color');
						$right_side_br_color=get_sub_field('right_side_br_color');
						$side=get_sub_field('side');

						switch ($side){
						case 'left': ?>
						<div class="full-pg">
							<div class="col-xs-12 col-md-6 half-pg" style="background-color:<?echo $right_side_br_color?>; background-image:url('<?echo $half_pg_br?>');">
								<div class="flex-center">
									<h1 style="color:<?echo $header_color?>"><?echo $header;?></h1>
									<div style="color:<?echo $copy_color?>"><?echo $body_copy;?></div>
								</div>
							</div>

						<?break;		
						case 'right': ?>
							<div class="col-xs-12 col-md-6 half-pg" style="background-color:<?echo $right_side_br_color?>; background-image:url('<?echo $half_pg_br?>');">
								<div class="flex-center">
									<h1 style="color:<?echo $header_color?>"><?echo $header;?></h1>
									<div style="color:<?echo $copy_color?>"><?echo $body_copy;?></div>
								</div>
							</div>
						</div>
					<?break;
					default:
				 		echo "No content";
				 	}

				endwhile;
					?></div><?
				else :
					echo "<h1> no content</h1>";
				endif;
				?></div><?
				break;

				default:
				 	echo "No content";
				 }

		// do something

	endwhile;

	else :

		//echo "<h1> no content ya honkey </h1>";

	endif;