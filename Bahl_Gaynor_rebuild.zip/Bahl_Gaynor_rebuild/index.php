<?php
get_header(); ?>


<main id="main" class="site-main" role="main">
	<div id="primary" class="main-content">

		<div class="col-xs-12 nopadding landing">
		test test test
		</div>
		<div class="col-xs-12 nopadding blue-curve">
		</div>
		<div class="col-xs-12 nopadding stats">
		</div>
		<div class="col-xs-12 nopadding statements">
		</div>
		<div class="col-xs-12 nopadding orange-block">
		</div>
		<div class="col-xs-12 nopadding video-block">
		</div>
		<div class="col-xs-12 nopadding twitter">
		</div>

	</div><!-- .content-area -->

</main><!-- .site-main -->


<?php get_footer(); ?>
