<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>

<!-- fonts -->
<!-- Font Awesome -->
<script src="https://use.fontawesome.com/b487819cd0.js"></script>	

<!-- Open Sans -->
<link async href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

<!-- Robo mono-->
<link href="https://fonts.googleapis.com/css?family=Roboto+Mono:300,400,500,700" rel="stylesheet">

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script>

//global for mouse_over_logo
var mouse_over_logo = false;

function scroll_stuff(offset)
{
	scroll_start = $(this).scrollTop();
    if (scroll_start > offset.top) {
        $(".header-container").css('background-color', 'white').css('box-shadow', '0 3px 15px rgba(0, 0, 0, 0.75)');
        $(".navigation ul li a").css('color', '#001C00');
        $("#not_green").css('color', '#001C00');
        $(".hamburg").css('color', '#001C00');
        $("ul.sub-menu li a").css('color','black');
        $("header .show-me.hamburg:before").css('color', '#001C00');
        $("#j-money").attr("src","/wp-content/uploads/2017/01/transparent-green-logo-short.png");
        console.log('inside if', mouse_over_logo, 'scroll:',scroll, 'scroll-start:',scroll_start, offset.top);

		if(mouse_over_logo && scroll_start > offset.top) {
		       $("#j-money").attr("src","/wp-content/uploads/2017/01/transparent-logo-short.png");
		       console.log('inside nested if');
		    } else {
		    	$("#j-money").attr("src","/wp-content/uploads/2017/01/transparent-green-logo-short.png");
		    	console.log('inside nested else');
		    }

		$(".home-link").mouseover(function(){
		   $("#j-money").attr("src","/wp-content/uploads/2017/01/transparent-logo-short.png");
		   mouse_over_logo = true;
		});

        $(".home-link").mouseout(function(){
		   $("#j-money").attr("src","/wp-content/uploads/2017/01/transparent-green-logo-short.png");
		   mouse_over_logo = false;
		});

		$("#menu-item-40").mouseout(function(){
	 		$(this).css('color','white');
	 	});

    } else {
        $('.header-container').css('background-color', 'transparent').css('box-shadow', '0 3px 15px rgba(0, 0, 0, 0)');
        $(".navigation ul li a").css('color', 'black');
        $(".hamburg").css('color', 'white');
        $("header .show-me.hamburg:before").css('color', 'white');
        $(".home-link-text").css('color', 'white');
        $("#j-money").attr("src","/wp-content/uploads/2017/01/transparent-logo-short.png");

    	$(".home-link").mouseout(function(){
		   $("#j-money").attr("src","/wp-content/uploads/2017/01/transparent-logo-short.png");
		   mouse_over_logo = false;
		});

    }
} //end scroll_stuff functon

$(document).ready(function () {
    var scroll_start = 0;
    var scroll = $(window).scrollTop();
    var startchange = $("html");
    var offset = startchange.offset();
  
    scroll_stuff(offset);

    $(".home-link").mouseout(function(){
    	mouse_over_logo = false;
	});

    $(".home-link").mouseover(function(){
    	mouse_over_logo = true;
	});



	console.log('inside main function', 'scroll', scroll, 'scroll-start',scroll_start, offset.top);

//this changes the of the nav and br
    if (startchange.length) {
        $(document).scroll(function () {
        	//scroll_stuff(offset);
        });
    }//end nav

//this displays the sub nav
    jQuery(function($) { 

	 $("#menu-item-40").click(function(){
	 	$(this).css('color','black');

	     var visibleMenu = $("ul.sub-menu:visible");
	     if (visibleMenu) {
	        $(visibleMenu).hide(); 
	    }
	    
	    $('ul.sub-menu').slideDown(function(){ 
	      $(this).css('height','70px').css('margin-top','0px').css('opacity','1.0').css('display','flex');
	      $("#menu-item-40").css('background-color',"#640008");
	  	});

	    $("#menu-item-40").mouseleave(function(){
	    $("ul.sub-menu").slideUp();
	    $("#menu-item-40").css('background-color',"inherit");
	  }); //end mouse leave
	}//end click

	);
	})//end desktop sub nav

//mobile sub nav
jQuery(function($) { 
	 $(".menu-item-40").click(function(){

	     var visibleMenu = $("ul.sub-menu:visible");
	     if (visibleMenu) {
	        $(visibleMenu).hide(); 
	    }

	    $('#menu-main-1 ul.sub-menu').slideDown(function(){ 
	      //$(this).css('display','flex').css('height','49px').css('border-top', '1px solid white').css('margin-top','10px').css('color','white!important');
	      $('.menu-item-40').css('padding-bottom','0px').css('transition','ease');
	  	});//end slide down

	    $("#menu-main-1 ul.sub-menu").mouseleave(function(){
	    $("#menu-main-1 ul.sub-menu").slideUp();
	    $('#menu-main-1 .menu-item-40').css('padding-bottom','10px').css('transition','ease');
	  });//end mouse leave
	}

	);
	})//end mobile sub nav

}); //emd doc.ready



jQuery(document).ready(function($) {

	$('.hamburg-click').on('touchstart', function() {
		$(this).addClass('show-me');
	});

	$('.hamburg-click').on('touchend', function() {
		$(this).removeClass('show-me');
	})

	$(".hamburg").click(function(){
		$(".hamburger-click").toggleClass('show-me');
		$(".hamburg").toggleClass('show-me');
		//$(".modal-lock").toggleClass('no-scroll');
		console.log("hello");
	});

	$(window).on('resize', function() {

		$('.hamburger-click, .hamburg').removeClass('show-me');
		$(".hamburg").removeClass('show-me');
		//$(".modal-lock").removeClass('no-scroll');

	});

});

</script>


</head>

<body <?php body_class(); ?> >
<div id="page" class="site">
	<div class="site-inner">
		<header id="masthead" class="site-header" role="banner">
			<div class="header-container">
			<div class="max-width-header">

			
			</div>
			</div>
			


<!-- 
				<div class="col-sm-2">
					<h1>this is not the content you're looking for</h1>
				</div>
 -->

			
		</header><!-- .site-header -->

		<div id="content" class="site-content">
