jQuery(document).ready(function($) {

	// $('.navBox').on('touchstart', function() {
	// 	$(this).addClass('.show-me');
	// });

	// $('.navBox').on('touchend', function() {
	// 	$(this).removeClass('.show-me');
	// })

	$(".hamburg").click(function(){
		$(".hamburger-click").toggleClass('.show-me');
		$(".hamburg").toggleClass('.show-me');
		//$(".modal-lock").toggleClass('no-scroll');
	});

	$(window).on('resize', function() {

		$('.hamburger-click, .hamburg').removeClass('.show-me');
		$(".hamburg").removeClass('.show-me');
		//$(".modal-lock").removeClass('no-scroll');

	});

	$(window).load(function() {
		// $(".twb-logo").css('filter','blur(0px)');
		$(".main-content").css('opacity','1');
		$(".twb-logo").css('opacity','1');
	});

});